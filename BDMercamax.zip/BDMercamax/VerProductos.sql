﻿CREATE VIEW [dbo].[VerProductos]
	AS
	SELECT nombre_producto, precio FROM [Producto]
