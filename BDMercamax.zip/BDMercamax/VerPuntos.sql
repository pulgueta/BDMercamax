﻿CREATE PROCEDURE [dbo].[VerPuntos]
	@user int
AS
	SELECT puntos_acumulados FROM Cliente
RETURN 0
